const apiKey = "85f5f0536f61b9e226c6fac4d8ed7395";
const apiUrl = "https://api.openweathermap.org/data/2.5/weather?units=metric&q=";

const searchBox = document.querySelector(".search-bar input");
const searchBtn = document.querySelector(".search-bar button");
const weatherIcon = document.querySelector(".weather-image");
const information = document.querySelector(".information_container");
const errorMessage = document.querySelector(".error");
var cityName = "Enter a city";


async function fetchCountryName(code) {
    const response = await fetch("Js/Countries.json");
    const countries = await response.json();
    return countries[code] || code;
}


async function checkWeather(city) {
    const response = await fetch(apiUrl + city + `&appid=${apiKey}`);

    if (response.status == 404) {
        errorMessage.style.display = "block";
        information.style.display = "none";
        cityName = "Enter a city";
    }
    else {
        var data = await response.json();

        const fullCountryName = await fetchCountryName(data.sys.country);

        cityName = data.name;

        document.querySelector("#city").innerHTML = data.name;
        document.querySelector("#country").innerHTML = fullCountryName;
        document.querySelector("#temp").innerHTML = Math.round(data.main.temp) + "°C";
        document.querySelector("#condition").innerHTML = data.weather[0].main;
        document.querySelector("#humidity").innerHTML = data.main.humidity + "%";
        document.querySelector("#wind").innerHTML = data.wind.speed + " km/h";

        if (data.weather[0].main == "Clear") {
            weatherIcon.src = "PICTURE/clear.png";
        }
        else if (data.weather[0].main == "Clouds") {
            weatherIcon.src = "PICTURE/clouds.png";
        }
        else if (data.weather[0].main == "Drizzle") {
            weatherIcon.src = "PICTURE/drizzle.png";
        }
        else if (data.weather[0].main === "Mist" || data.weather[0].main === "Fog" || data.weather[0].main === "Haze") {
            weatherIcon.src = "PICTURE/mist.png";
        }
        else if (data.weather[0].main == "Rain") {
            weatherIcon.src = "PICTURE/rain.webp";
        }
        else if (data.weather[0].main == "Snow") {
            weatherIcon.src = "PICTURE/snow.png";
        }

        information.style.display = "block";
        errorMessage.style.display = "none";
    }

    console.log(data);
}

searchBtn.addEventListener("click", async () => {
    await checkWeather(searchBox.value);
    searchBox.value = "";
    searchBox.placeholder = cityName;
})